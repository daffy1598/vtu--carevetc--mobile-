﻿namespace CarevecMobile.Constants
{
    public static class GlobalConstants
    {
        public const string AdminArea = "Admin";
        public const string AdminRole = "Administrator";

        public const string UserArea = "NormalUser";
        public const string UserRole = "User";
    }
}
